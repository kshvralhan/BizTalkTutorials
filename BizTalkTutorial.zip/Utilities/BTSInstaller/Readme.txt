The BTSInstaller utility has been removed in Microsoft BizTalk Server 2009. Please refer to the documentation on how to migrate BTSInstaller MSI's to Microsoft BizTalk Server 2009.
