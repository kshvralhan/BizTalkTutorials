using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Interface Developer Tutorial")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft BizTalk Server")]
[assembly: AssemblyCopyright("Copyright � Microsoft Corporation. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("C:\\Microsoft EDI Tutorial\\EDI Inbound Processing\\keyfile.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyDefaultAlias("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
[assembly: Microsoft.XLANGs.BaseTypes.BizTalkAssemblyAttribute(typeof(Microsoft.BizTalk.XLANGs.BTXEngine.BTXService))]


// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("5955f9e5-b760-4947-be8c-f97d53f3fd1b")]
