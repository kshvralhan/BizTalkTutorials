The Tutorial Files are compacted into a self extracting CAB file
Please run Unpack.cmd to deploy the files to the proper place.
